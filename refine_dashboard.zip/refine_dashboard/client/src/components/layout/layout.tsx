// Layout.tsx

import React from 'react';

interface LayoutProps {
  title: string;
  children: string;
}

export const Layout: React.FC<LayoutProps> = ({ title , children }) => {
  return (
    <div>
      <h1>{title}</h1>
      {children}
    </div>
  );
};


